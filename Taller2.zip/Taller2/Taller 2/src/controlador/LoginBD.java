/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import vista.ventRegistrar;

/**
 *
 * @author Antonia
 */
public class LoginBD {
     public static void main(String[] args) {
        // TODO code application logic here

        ventRegistrar v = new ventRegistrar();
        v.setVisible(true);
        
    }
}
